// Sumner Bradley
public class MusicDepartment extends Department {
    MusicDepartment(String name){ super(name);}
}
