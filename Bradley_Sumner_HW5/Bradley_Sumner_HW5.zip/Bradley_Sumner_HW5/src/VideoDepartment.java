// Sumner Bradley
public class VideoDepartment extends Department {
    VideoDepartment(String name){ super(name);}
}
