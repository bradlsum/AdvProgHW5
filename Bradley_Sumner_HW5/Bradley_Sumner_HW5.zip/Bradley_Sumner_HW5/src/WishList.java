// Sumner Bradley
public class WishList extends ItemList {
    WishList(){
        super();
    }

    WishList(Item i){
        super(i);
    }
}
