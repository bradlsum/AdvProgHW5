// Sumner Bradley
public class SoftwareDepartment extends Department {
    SoftwareDepartment(String name){ super(name);}
}
