// Sumner Bradley
public class ShoppingCart extends ItemList {
    ShoppingCart(){
        super();
    }

    ShoppingCart(Item i){
        super(i);
    }
}
