// Sumner Bradley
public class BookDepartment extends Department {
    BookDepartment(String name){
        super(name);
    }
}
